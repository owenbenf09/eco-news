Eco News — Continuous Scroll Prototype

This version removes the boxed news-card grid and turns the homepage into a continuous editorial feed.

Changes:
- News cards replaced with full-width story rows.
- Stories flow vertically with dividers instead of separate cards.
- Each story has a large image area and editorial-style headline.
- Mobile layout stacks the image above the story.
- Category filters still work.
- Planet Explorer / interactive Earth remains included.

This is a prototype. Internet access is required for the Planet Explorer map.
